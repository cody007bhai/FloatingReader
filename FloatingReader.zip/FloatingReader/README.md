# Floating Reader

APK बनाने के 2 तरीके:

## 1) GitHub से (Android Studio की ज़रूरत नहीं)
1. github.com पर free account → नया repository बनाएँ।
2. इस folder की सारी files upload करें (".github" folder समेत)।
   अगर ".github" upload न हो: "Add file → Create new file" में नाम `.github/workflows/build.yml` लिखकर
   इस project वाली build.yml की content paste करें।
3. ऊपर "Actions" tab → "Build APK" run हरा (✔) होने तक रुकें (~5 मिनट)।
4. run खोलकर नीचे "FloatingReader-apk" download करें → zip खोलने पर `app-debug.apk` मिलेगा → फ़ोन में install करें।

## 2) Android Studio से
Folder खोलें → Build > Build APK(s) → `app/build/outputs/apk/debug/app-debug.apk`
