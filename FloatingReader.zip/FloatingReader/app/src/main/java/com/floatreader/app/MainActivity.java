package com.floatreader.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(22), dp(48), dp(22), dp(28));
        col.setBackgroundColor(0xFFF6F5FB);
        col.addView(label("Floating Reader", 28, true, 0xFF1D1D35));
        col.addView(label("Copy या select किया हुआ Hindi + English text, फ़ोन की Google Text-to-speech आवाज़ में सुनें।\n\n"
                + "तरीका 1: किसी भी app में text select करें → Copy वाले मेनू (⋮ More) में “बोलो (Speak)” दबाएँ।\n\n"
                + "तरीका 2: text Copy करें → Floating बटन खोलकर ▶ दबाएँ। स्पीड − / + से बदलें।\n\n"
                + "Links, emoji और फ़ालतू symbols अपने-आप हटा दिए जाते हैं।", 15, false, 0xFF4A4A68));
        col.addView(button("1. Overlay permission दें", v -> startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())))));
        col.addView(button("2. Floating बटन चालू करें", v -> {
            if (!Settings.canDrawOverlays(this))
                Toast.makeText(this, "पहले Overlay permission दें", Toast.LENGTH_LONG).show();
            else send(FloatingService.ACTION_SHOW, null);
        }));
        col.addView(button("Test: बोलकर सुनाओ", v -> send(FloatingService.ACTION_SPEAK,
                "नमस्ते! यह Floating Reader का test है. आज की meeting 5 बजे है, please time पर join करना.")));
        col.addView(button("Phone की Text-to-speech settings", v -> {
            try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }
            catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        }));
        col.addView(button("Floating बटन बंद करें", v -> stopService(new Intent(this, FloatingService.class))));
        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        setContentView(sv);
    }

    private void send(String action, String text) {
        Intent i = new Intent(this, FloatingService.class).setAction(action);
        if (text != null) i.putExtra(FloatingService.EXTRA_TEXT, text);
        startForegroundService(i);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView label(String s, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, 0, 0, dp(14));
        return t;
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setOnClickListener(l);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF5B5BD6);
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
        p.topMargin = dp(12);
        b.setLayoutParams(p);
        return b;
    }
}
