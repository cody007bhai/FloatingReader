package com.floatreader.app;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Cleans copied text (links, emoji, markdown symbols) and splits it into Hindi / English speech chunks. */
final class TextCleaner {
    static final class Chunk {
        final String text;
        final boolean hindi;
        Chunk(String text, boolean hindi) { this.text = text; this.hindi = hindi; }
    }

    private static final Pattern LINKS = Pattern.compile(
            "(?i)(?:https?://|www\\.)\\S+|\\b[\\w.+-]+@[\\w-]+(?:\\.[\\w-]+)+\\b"
                    + "|\\b(?:[a-z0-9-]+\\.)+(?:com|org|net|io|edu|gov)\\b(?:/\\S*)?");

    static String clean(String s) {
        s = LINKS.matcher(s).replaceAll(" ");
        s = s.replaceAll("[\\p{So}\\p{Sk}\\uFE0F\\u2022]", " ");
        s = s.replaceAll("[*_#~`|<>\\[\\]{}^\\\\]+|-{2,}|={2,}", " ");
        s = s.replaceAll("[ \\t\\u00A0]+", " ").replaceAll("\\s*\\n\\s*", "\n");
        return s.trim();
    }

    /** Sentence by sentence; inside a sentence, Devanagari runs use the Hindi voice, long English runs the English voice. */
    static List<Chunk> chunks(String raw) {
        List<Chunk> out = new ArrayList<>();
        for (String s : clean(raw).split("(?<=[.!?\\u0964\\u0965])\\s+|\\n+")) {
            if (hasWord(s)) sentence(s, out);
        }
        return out;
    }

    private static void sentence(String s, List<Chunk> out) {
        List<StringBuilder> text = new ArrayList<>();
        List<Boolean> hindi = new ArrayList<>();
        List<Integer> english = new ArrayList<>();
        for (String w : s.trim().split("\\s+")) {
            int k = kind(w), n = text.size() - 1;
            if (n >= 0 && (k == 0 || hindi.get(n) == (k == 1))) {
                text.get(n).append(' ').append(w);
                if (k == 2) english.set(n, english.get(n) + 1);
            } else {
                text.add(new StringBuilder(w));
                hindi.add(k == 1);
                english.add(k == 2 ? 1 : 0);
            }
        }
        boolean anyHindi = hindi.contains(true);
        List<Chunk> runs = new ArrayList<>();
        for (int i = 0; i < text.size(); i++) {
            // short English bits inside a Hindi sentence stay with the Hindi voice (no choppy switching)
            boolean h = hindi.get(i) || (anyHindi && english.get(i) < 4);
            int last = runs.size() - 1;
            if (last >= 0 && runs.get(last).hindi == h)
                runs.set(last, new Chunk(runs.get(last).text + " " + text.get(i), h));
            else runs.add(new Chunk(text.get(i).toString(), h));
        }
        for (Chunk c : runs) cap(c, out);
    }

    private static void cap(Chunk c, List<Chunk> out) {
        String x = c.text;
        while (x.length() > 400) {
            int cut = x.lastIndexOf(' ', 400);
            if (cut < 100) cut = 400;
            out.add(new Chunk(x.substring(0, cut).trim(), c.hindi));
            x = x.substring(cut).trim();
        }
        if (hasWord(x)) out.add(new Chunk(x, c.hindi));
    }

    /** 0 = neutral (digits/punctuation), 1 = Devanagari word, 2 = other letters (English). */
    private static int kind(String w) {
        boolean letter = false;
        for (int i = 0; i < w.length(); ) {
            int c = w.codePointAt(i);
            i += Character.charCount(c);
            if (!Character.isLetter(c)) continue;
            if (c >= 0x0900 && c <= 0x097F) return 1;
            letter = true;
        }
        return letter ? 2 : 0;
    }

    private static boolean hasWord(String s) {
        for (int i = 0; i < s.length(); i++) if (Character.isLetterOrDigit(s.charAt(i))) return true;
        return false;
    }
}
