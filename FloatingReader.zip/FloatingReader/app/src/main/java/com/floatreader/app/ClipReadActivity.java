package com.floatreader.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;

/** Invisible screen: Android 10+ lets only the focused app read the clipboard, so we take focus for a blink. */
public class ClipReadActivity extends Activity {
    private boolean done;

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus || done) return;
        done = true;
        String text = null;
        try {
            ClipData d = ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).getPrimaryClip();
            if (d != null && d.getItemCount() > 0) {
                CharSequence cs = d.getItemAt(0).coerceToText(this);
                if (cs != null) text = cs.toString();
            }
        } catch (Exception ignored) { }
        startService(new Intent(this, FloatingService.class)
                .setAction(FloatingService.ACTION_CLIP)
                .putExtra(FloatingService.EXTRA_TEXT, text));
        finish();
        overridePendingTransition(0, 0);
    }
}
