package com.floatreader.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.util.DisplayMetrics;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Holds the TextToSpeech engine (the phone's default, e.g. Google) and the floating control bubble. */
public class FloatingService extends Service {
    static final String ACTION_SHOW = "com.floatreader.SHOW", ACTION_SPEAK = "com.floatreader.SPEAK",
            ACTION_CLIP = "com.floatreader.CLIP", ACTION_QUIT = "com.floatreader.QUIT", EXTRA_TEXT = "text";
    private static final String CHANNEL = "reader";

    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private TextToSpeech tts;
    private boolean ttsReady, pendingStart, playing, expanded;
    private List<TextCleaner.Chunk> chunks = new ArrayList<>();
    private int idx, token;
    private String lastRaw = "";
    private Boolean curHindi;
    private float rate;

    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private LinearLayout root, panel;
    private ImageButton playBtn;
    private TextView speedTv;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("reader", MODE_PRIVATE);
        rate = prefs.getFloat("rate", 1f);
        startAsForeground();
        tts = new TextToSpeech(getApplicationContext(), status -> {
            if (status != TextToSpeech.SUCCESS) {
                toast("Text-to-speech शुरू नहीं हुआ — phone की TTS settings देखें");
                return;
            }
            ttsReady = true;
            tts.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { }
                @Override public void onDone(String id) { advance(id); }
                @Override public void onError(String id) { advance(id); }
            });
            if (pendingStart) { pendingStart = false; speakCurrent(); }
        });
    }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        String a = in == null ? null : in.getAction();
        if (ACTION_QUIT.equals(a)) { stopSelf(); return START_NOT_STICKY; }
        String t = in == null ? null : in.getStringExtra(EXTRA_TEXT);
        showBubble();
        if (ACTION_SPEAK.equals(a)) {
            load(t);
        } else if (ACTION_CLIP.equals(a)) {
            if (t == null || t.trim().isEmpty()) toast("Clipboard खाली है — पहले कुछ text copy करें");
            else if (!playing && idx < chunks.size() && t.equals(lastRaw)) speakCurrent(); // resume after pause
            else load(t);
        }
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) { }
            root = null;
        }
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    // ---------- speech ----------

    private void load(String raw) {
        if (raw == null) return;
        chunks = TextCleaner.chunks(raw);
        idx = 0;
        lastRaw = raw;
        if (chunks.isEmpty()) { toast("बोलने लायक text नहीं मिला"); return; }
        if (root != null && !expanded) setExpanded(true);
        speakCurrent();
    }

    private void speakCurrent() {
        if (!ttsReady) { pendingStart = true; return; }
        if (idx >= chunks.size()) { playing = false; chunks.clear(); idx = 0; refreshUi(); return; }
        TextCleaner.Chunk c = chunks.get(idx);
        if (curHindi == null || curHindi != c.hindi) {
            curHindi = c.hindi;
            int r = tts.setLanguage(c.hindi ? new Locale("hi", "IN") : new Locale("en", "IN"));
            if (r < TextToSpeech.LANG_AVAILABLE) {
                if (c.hindi) toast("Hindi voice नहीं मिली — Settings > Text-to-speech में Hindi data install करें");
                else tts.setLanguage(Locale.US);
            }
        }
        tts.setSpeechRate(rate);
        playing = true;
        refreshUi();
        tts.speak(c.text, TextToSpeech.QUEUE_FLUSH, null, String.valueOf(++token));
    }

    private void advance(String id) {
        main.post(() -> {
            if (playing && String.valueOf(token).equals(id)) { idx++; speakCurrent(); }
        });
    }

    private void pause() { playing = false; token++; tts.stop(); refreshUi(); }

    private void stopAll() {
        playing = false;
        token++;
        if (tts != null) tts.stop();
        chunks.clear();
        idx = 0;
        refreshUi();
    }

    private void onPlay() {
        if (playing) { pause(); return; }
        // read the clipboard fresh (needs a focused window on Android 10+)
        startActivity(new Intent(this, ClipReadActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }

    private void changeRate(float d) {
        rate = Math.max(0.5f, Math.min(3f, rate + d));
        prefs.edit().putFloat("rate", rate).apply();
        speedTv.setText(rate + "x");
        if (playing) speakCurrent(); // restart the current sentence at the new speed
    }

    private void refreshUi() {
        if (playBtn != null) playBtn.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
    }

    // ---------- floating bubble ----------

    private void showBubble() {
        if (root != null) return;
        if (!Settings.canDrawOverlays(this)) {
            toast("Floating बटन के लिए app खोलकर Overlay permission दें");
            return;
        }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        root = new LinearLayout(this);
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setPadding(dp(4), dp(4), dp(4), dp(4));
        root.setBackground(round(0xF0262640, dp(30)));

        ImageView handle = new ImageView(this);
        handle.setImageResource(R.drawable.ic_speaker);
        handle.setPadding(dp(10), dp(10), dp(10), dp(10));
        handle.setBackground(round(0xFF5B5BD6, dp(22)));
        root.addView(handle, new LinearLayout.LayoutParams(dp(44), dp(44)));

        panel = new LinearLayout(this);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        playBtn = btn(R.drawable.ic_play, v -> onPlay());
        speedTv = new TextView(this);
        speedTv.setTextColor(Color.WHITE);
        speedTv.setTextSize(13);
        speedTv.setGravity(Gravity.CENTER);
        speedTv.setMinWidth(dp(46));
        speedTv.setText(rate + "x");
        panel.addView(playBtn);
        panel.addView(btn(R.drawable.ic_stop, v -> stopAll()));
        panel.addView(btn(R.drawable.ic_remove, v -> changeRate(-0.25f)));
        panel.addView(speedTv);
        panel.addView(btn(R.drawable.ic_add, v -> changeRate(0.25f)));
        panel.addView(btn(R.drawable.ic_close, v -> stopSelf()));
        root.addView(panel);

        lp = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = prefs.getInt("x", dp(8));
        lp.y = prefs.getInt("y", dp(240));

        // drag the speaker icon to move; tap it to open / close the controls
        handle.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = lp.x; sy = lp.y; tx = e.getRawX(); ty = e.getRawY(); moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        if (moved) { lp.x = sx + (int) dx; lp.y = sy + (int) dy; wm.updateViewLayout(root, lp); }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) clamp(); else setExpanded(!expanded);
                        return true;
                }
                return false;
            }
        });
        wm.addView(root, lp);
        setExpanded(true);
    }

    private void setExpanded(boolean e) {
        expanded = e;
        panel.setVisibility(e ? View.VISIBLE : View.GONE);
        clamp();
    }

    private void clamp() { // keep the bubble on screen and remember its position
        root.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        DisplayMetrics m = getResources().getDisplayMetrics();
        lp.x = Math.max(0, Math.min(lp.x, m.widthPixels - root.getMeasuredWidth()));
        lp.y = Math.max(0, Math.min(lp.y, m.heightPixels - root.getMeasuredHeight()));
        wm.updateViewLayout(root, lp);
        prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply();
    }

    private ImageButton btn(int icon, View.OnClickListener l) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(icon);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setPadding(dp(8), dp(8), dp(8), dp(8));
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
        return b;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); }

    private void startAsForeground() {
        getSystemService(NotificationManager.class).createNotificationChannel(
                new NotificationChannel(CHANNEL, "Floating Reader", NotificationManager.IMPORTANCE_LOW));
        PendingIntent quit = PendingIntent.getService(this, 0,
                new Intent(this, FloatingService.class).setAction(ACTION_QUIT), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_speaker)
                .setContentTitle("Floating Reader चालू है")
                .setContentText("बंद करने के लिए Close दबाएँ")
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_close), "Close", quit).build())
                .build();
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(1, n);
    }
}
