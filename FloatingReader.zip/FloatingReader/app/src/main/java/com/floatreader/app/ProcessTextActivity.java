package com.floatreader.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/** Shows "बोलो (Speak)" in the text-selection menu (next to Copy / in the ⋮ menu) of any app. */
public class ProcessTextActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        CharSequence t = getIntent().getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
        if (t != null && t.length() > 0) {
            startForegroundService(new Intent(this, FloatingService.class)
                    .setAction(FloatingService.ACTION_SPEAK)
                    .putExtra(FloatingService.EXTRA_TEXT, t.toString()));
        }
        finish();
    }
}
